# For IDA v6.1 analysis of Grand Prix World
# Script file to assist with disassembly of gpw.exe v1.01b
# To be applied to gpw.exe v1.01b that has been modified by GpwEdit to:
#     include switch idiom
#     include jump bypass
#     include code shift
#     include global unlock
#     include points system upgrade
#     exclude other enhancements (e.g. no cd, gfx/sfx fixes)

# Suggested load: vc32rtf

# Mark bytes as functions
#def apply_make_functions():
	# MakeFunction https://www.hex-rays.com/products/ida/support/idadoc/330.shtml
	# MakeFunction(0x0043B117)

# Mark bytes as code
#def apply_make_code():
	# MakeCode https://www.hex-rays.com/products/ida/support/idadoc/201.shtml 
	
# Name and prefix user identified functions to uf_ and names to un_
def apply_names():
	# MakeName https://www.hex-rays.com/products/ida/support/idadoc/203.shtml

	# Random
	MakeName(0x00401000, "uf_GlobalUnlockFix")
	MakeName(0x00435CB8, "uf_IsFileExist")
	MakeName(0x0043B0A8, "uf_CreateFont")

	# Buffers
	MakeName(0x00490B6B, "uf_LoadDataFromFileIntoBuffer")
	MakeName(0x00726AC8, "un_DataBufferByteCount")
	MakeName(0x00726ACC, "un_DataBuffer")
	#MakeName(0x0067D675, "uf_") # TODO does this clear buffer/relocate buffer pointer?

	# Resource strings
	MakeName(0x00513887, "uf_LoadResourceStringValueIntoDataBuffer1")
	MakeName(0x005138E2, "uf_LoadResourceStringValueIntoDataBuffer2")
	MakeName(0x0051393D, "uf_LoadResourceStringValueIntoDataBuffer3")
	
	MakeName(0x005133A7, "uf_LoadResourceStrings")
	MakeName(0x00514991, "uf_LoadResourceStringsIntoGlobalArray") # TODO takes parameters SID, memloc, recordCount, recordSize	
	MakeName(0x00D4E4B8, "un_LoadResourceStringsGlobalTextOverrunCount")
	
	# Startup
	MakeName(0x0067BF70, "uf_IsPrimaryDisplayPowerVr2")
	MakeName(0x00546AE0, "uf_LoadDataFromFileLanguageTxt")
	MakeName(0x0047E128, "uf_LoadDataFromFileGpwCfg")
	MakeName(0x0049D3C8, "uf_SetGpwRegistryKeyPath")
	MakeName(0x00538A80, "uf_SetPowerVr2AppHint")
	MakeName(0x005132D0, "uf_SetLanguage")

	# Window
	MakeName(0x00438D4B, "uf_WndProc")
	MakeName(0x00439569, "uf_LoadWindow")
	MakeName(0x004544C2, "uf_IsCursorWithinXYBounds")
	MakeName(0x0045452F, "uf_IsCursorWithinXBounds")
	MakeName(0x00692C68, "un_WindowHandle1")
	MakeName(0x00692CA0, "un_WindowHandle2")
	MakeName(0x015F2F24, "un_WindowName")
	MakeName(0x00692C70, "un_WindowClientRect")
	
	# Mouse
	MakeName(0x00692C88, "un_WM_LBUTTONDOWN_WPARAM")
	MakeName(0x00692414, "un_WM_LBUTTONDOWN_LPARAM_X")
	MakeName(0x00692418, "un_WM_LBUTTONDOWN_LPARAM_Y")
	MakeName(0x0044F289, "uf_WM_KEYDOWN_Handler1") # TODO why does this switch on dword_15F2C90
	MakeName(0x00420388, "uf_WM_KEYDOWN_Handler2") # TODO why does this switch on dword_15F2C90

	# Graphics
	MakeName(0x0043D7EF, "uf_LoadDirectDraw")
	MakeName(0x004353E0, "uf_LoadDataFromFileTga")

	# Timer20
	MakeName(0x0043005E, "uf_CreateTimer20")
	MakeName(0x015F2AC0, "un_Timer20Counter")
	MakeName(0x004300C6, "uf_GetTimer20Counter")
	MakeName(0x0043008D, "uf_SetTimer20Counter")
	
	# TimerUndefined1
	MakeName(0x014DE2D0, "un_TimerUndefined1")
	MakeName(0x0047AA47, "uf_TimerProcUndefined1")
	MakeName(0x007269C0, "un_TimerUndefined1Counter")

	# Movies
	MakeName(0x00438266, "uf_StartStreamingAvi")
	MakeName(0x004381C0, "uf_StopStreamingAvi")
	MakeName(0x015F2C0C, "un_IsStreamingAvi")
	
    # Commentary
	MakeName(0x00520FB0, "uf_LoadCommentaryResourceStrings")
	MakeName(0x007A7DE0, "un_CommentaryFileNames")
	MakeName(0x0079ED58, "un_CommentaryTranscriptions")

	# Track
	MakeName(0x00491337, "uf_LoadDataFromFileTrackRti")
	MakeName(0x00729A48, "un_LoadDataFromFileTrackRtiCounter")
	
	# Track conditions
	#MakeName(0x0070C798, "uf_TrackDrynessRating") # TODO check conditions or dryness?
	
	# 67D854 = _strchr according to vc32rtf
	# 67CDFA = _sprintf according to vc32rtf

	# TODO sub_514320 - Loads strings containing variable names?
	# TODO sub_514C80 - Loads strings containing display text?

	# Flags
	MakeName(0x015F2C74, "un_IsFileStartDatExist")
	MakeName(0x015F2C78, "un_IsFileBoxonDatExist")
	MakeName(0x015F2C7C, "un_IsFileFrameDatExist")
	MakeName(0x015F2C80, "un_IsFileCoordsDatExist")
	MakeName(0x015F2C84, "un_IsFileUnlimitDatExist")
	MakeName(0x015F2C88, "un_IsFileLowresDatExist")
	MakeName(0x015FA880, "un_IsLanguageEnglish")
	MakeName(0x015FA884, "un_IsLanguageFrench")
	MakeName(0x015FA888, "un_IsLanguageGerman")
	
	# 7169B0 - game speed setting 50-150%
	
# Add comments
#def apply_comments():
	# MakeComm https://www.hex-rays.com/products/ida/support/idadoc/204.shtml 

################################################################################

#apply_make_functions()
#apply_make_codes()
apply_names()
#apply_comments()
