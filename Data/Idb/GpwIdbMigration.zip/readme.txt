21-Apr-2017

----- MIGRATION WORK (gpwxp.exe to gpw.exe v1.01b) -----

Copy all useful function and variable names from gpwxp.exe and remap
them to the new locations in the gpw.exe, and script to python file.

Conclusion for functions: Use gpwxp.idb (or 23), see if anything useful in initial

Conclusion for names: Use gpwxp.idb (or 23), see if anything useful in initial

------------------------------------------------------------





---- OLD GPWXP WORK BELOW TO REACH ABOVE CONCLUSIONS -----

- gpwxp initial attempt seems to have stuff that may not be in others?
- gpwxp 20130723 or backupmdbs\old_idbs file seems legit

functions
---------
initial->5 has differences
5-> 6 has updates in 6
5->13 has updates in 13
13-14 identical
14-17 has updates in 17
17-23 has updates in 23
23->old_idbs\gpwxp.idb has a few functions defined in old_idbs (worthless)

Conclusion: Use 23 or old_idbs\gpwxp.idb, see if anything useful in initial

names
-----
initial->5 has differences
5-> 6 has updates in 6
5->13 has updates in 13
13-14 identical
14-17 has updates in 17
17-23 has updates in 23
23->old_idbs\gpwxp.idb has a few DirectSound labels defined (useful)

backupidbs\gpw.idb has nothing of interest it appears
backupidbs\gpw_gpwxpsettings.idb has nothing of interest it appears
backupidbs\oldidbs\gpw.idb has nothing of interest it appears
backupidbs\oldidbs\gpwxp.idb has a few DirectSound labels defined (useful)

Conclusion: Use old_idbs\gpwxp.idb, see if anything useful in initial
